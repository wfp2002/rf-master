<?php
include "razorflow.php";

Dashboard::setTitle("Dashboard de Vendas");

$chart = new ChartComponent;
$chart->setCaption("Tracking BRASIL Acumulado");
$chart->setDimensions(4,2);
//$chart->setYAxis("Volume HL");
$chart->setStaticLabels("Regional", array("SPC", "NE", "CO", "NO", "RJ", "RSSC", "PRSPI", "MGES"));
$chart->addStaticSeries("Real (hl)", array(30, 23, 22, 23,30, 22,33,28), array(
	'numberSuffix' => " (hl)"
	
));
$chart->addStaticSeries("Tracking", array(13, 12, 11, 13, 22 ,11,23,33), array(
	'numberSuffix' => " (hl)",
	'displayType' => "Line"
));



$chart2 = new ChartComponent;
$chart2->setCaption("Tracking Diario - REGIONAL SPC");
$chart2->setDimensions(4,2);
//$chart->setYAxis("Volume HL");
$chart2->setStaticLabels("DIAS", array("1", "2", "3", "4", "5", "6", "7", "8", "9","10","11", "12", "13", "14", "15", "16", "17", "18", "19"));
$chart2->addStaticSeries("Real (hl)", array(30, 23, 22, 23,30, 22,33,28,13, 12, 11, 13, 22 ,11,23,33,23,25,23), array(
	'numberSuffix' => " (hl)",
	'displayType' => "Line"
));
$chart2->addStaticSeries("Tracking", array(13, 12, 11, 13, 22 ,11,23,33,23,30, 22,33,28,13, 12, 11, 13, 22 ,11), array(
	'numberSuffix' => " (hl)",
	'displayType' => "Line"
));
$chart2->addTrendLine("avg BGT", 28);




$chart3 = new ChartComponent;
$chart3->setCaption("Marcas - REGIONAL SPC");
$chart3->setDimensions(4,1);
//$chart->setYAxis("Volume HL");
$chart3->setStaticLabels("", array("SK", "BC", "AP", "BUD", "STELLA", "PREMIUM", "OUTRAS"));
$chart3->addStaticSeries("Real x Ano Anterior", array(30, 23, 22, 23,30, 22,33), array(
	'numberSuffix' => " (hl)",
	'color' => '#FFa006'
	
));

$marcas = new ChartComponent;
$marcas->setCaption("Marcas - REGIONAL SPC");
$marcas->setDimensions(4,1);
//$chart->setYAxis("Volume HL");
$marcas->setStaticLabels("", array("GCA", "PepsiCO", "PC", "H2O", "Gatorade", "Lipton", "OUTRAS"));
$marcas->addStaticSeries("Real x Ano Anterior", array(30, 23, 22, 23,30, 22,33), array(
	'numberSuffix' => " (hl)",
	'color' => '#cca022'
	
));


$chart4 = new ChartComponent;
$chart4->setCaption("Embalagens - REGIONAL SPC");
$chart4->setDimensions(2,1);
$chart4->setYAxis("Volume HL");
$chart4->setStaticLabels("", array("RGB", "OW", "REFRI", "NANC", "AGUA", "ENERGETICO",));
$chart4->addStaticSeries("Real x Ano Anterior", array(1, 2, 2, 1,3, 2), array(
	'numberSuffix' => "%",
	'showValues' => 1
	
));
$chart4->addStaticSeries("Real x Meta", array(2, 1, 2, 1,2, 3), array(
	'numberSuffix' => "%",
	'displayType' => 'Line',
	'showValues' => 0
	
));


$chart5 = new ChartComponent;
$chart5->setCaption("EMBALAGENS - RGB - REGIONAL SPC");
$chart5->setDimensions(2,1);
$chart5->setYAxis("Volume HL");
$chart5->setStaticLabels("", array("1/1", "Litrao", "Litrinho", "CHOPP"));
$chart5->addStaticSeries("Real x Ano Anterior", array(5, 7, 2,4), array(
	'numberSuffix' => "%",
	'showValues' => 1,
	'color' => '#00FF00'
	
));
$chart5->addStaticSeries("Real x Meta", array(3, 5, 4, 2), array(
	'numberSuffix' => "(%)",
	'displayType' => 'Line',
	'showValues' => 0
	
	
));


$table = new TableComponent();
$table->setCaption("Vendas");
$table->setDimensions(4,1);
$table->addStaticColumn("Regional");
$table->addStaticColumn("Cerv.TT");
$table->addStaticColumn("OW");
$table->addStaticColumn("RGB");
$table->addStaticColumn("Litro");
$table->addStaticColumn("1/2");
$table->addStaticColumn("1/1");
$table->addStaticColumn("Lata530");
$table->addStaticColumn("BUD");
$table->addStaticColumn("Refrinanc");
$table->addStaticRow (array("CO",  29,87,36,76,23,56,34,67,89, "2/3/2002"));
$table->addStaticRow (array("SPC", 40,81,34,56,23,56,78,45,23, "2/3/2003"));
$table->addStaticRow (array("NE",  30,92,34,56,67,34,12,40,78, "2/3/2002"));
$table->addStaticRow (array("MGES", 2,87,34,56,67,34,67,78,45, "2/3/2002"));
$table->addStaticRow (array("RSSC", 4,81,12,34,45,56,76,89,45, "2/3/2003"));
$table->addStaticRow (array("PRSPI", 3,92,23,45,67,78,89,45,34, "2/3/2002"));
$table->addStaticRow (array("RJ",   4,81,23,45,23,45,23,45,67, "2/3/2003"));
$table->addStaticRow (array("NO",    3,92,34,45,56,67,78,56,45, "2/3/2002"));




$pie = new ChartComponent;
$pie->setCaption("Peso Canal - REGIONAL SPC");
$pie->setDimensions(2,2);
//$chart->setYAxis("Volume HL");
$pie->setStaticLabels("Regional", array("AS", "3PD", "ROTA"));
$pie->addStaticSeries("Real (hl)", array(30,30,40), array(
	'numberSuffix' => " (%)",
	'displayType' => "Pie"
	
	
));



Dashboard::addComponent($chart);
//Dashboard::addComponent($pie);
Dashboard::addComponent($table);
Dashboard::addComponent($chart2);
Dashboard::addComponent($chart3);
Dashboard::addComponent($marcas);
Dashboard::addComponent($chart4);
Dashboard::addComponent($chart5);


Dashboard::Render();
?>






<!--
//Nome do Dashboard
Dashboard::setTitle ("DASH Vendas");

//Criando o DataSource
$dataSource = new MySQLDataSource('fui', 'root', '', 'localhost');
$dataSource->setSQLSource("KPI_VOLUME_TTV");
						  

$filter = new ConditionFilterComponent();
$filter->setDimensions(1, 1);
$filter->setDataSource($dataSource);
$filter->setCaption("Regional");
$filter->addSelectCondition("Regional", array("GEO SPC", "GEO RJ"), array(
  "KPI_VOLUME_TTV.nom_abr_unb_dir = 'GEO SPC'",
  "KPI_VOLUME_TTV.nom_abr_unb_dir = 'GEO RJ'"
  
));



// Criando grafico de Vendas Regional
$vendasRegional = new ChartComponent();
$vendasRegional->setCaption ("Vendas Regional");
$vendasRegional->setDimensions(3, 1);
$vendasRegional->setDataSource($dataSource);
$vendasRegional->setLabelExpression("Regional", "KPI_VOLUME_TTV.nom_abr_unb_dir", array('autoDrill' => true));
$vendasRegional->addSeries("Vendas", "KPI_VOLUME_TTV.qtd_total_sku", array('sort' => "DESC", 'color' => "223965"));

// Criando grafico de Vendas Regional
$vendasProduto = new ChartComponent();
$vendasProduto->setCaption("Mais Vendidos","Mais Vendidos: {{label}}");
$vendasProduto->setDimensions(4, 1);
$vendasProduto->setDataSource($dataSource);
$vendasProduto->setLabelExpression("Produto", "KPI_VOLUME_TTV.nom_prod", array('autoDrill' => true));
$vendasProduto->addSeries("Vendas", "KPI_VOLUME_TTV.qtd_total_sku", array('sort' => "DESC", 'color' => "223965"
));

$genreChart = new ChartComponent();
$genreChart->setDimensions(4,2);
$genreChart->setCaption("Grafico Produtos","Grafico Produtos: {{label}}");
$genreChart->setDataSource($dataSource);
$genreChart->setLabelExpression("Month", "kpi_volume_ttv.dat_ref", array(
	'timestampRange' => true,
	'timeUnit' => 'month',
	'autoDrill' => true
));

$genreChart->addSeries("CERVEJA", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'CERVEJA'",
	'displayType' => 'Line',
	'showValues' => 0
));


$genreChart->addSeries("REFRI", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'REFRIGERANTE'",
	'displayType' => 'Line',
	'showValues' => 0
));

$genreChart->addSeries("REFRI LATA 350", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'REFRIGERANTE' AND kpi_volume_ttv.nom_lin_emb_consolid = 'LATA 350'",
	
	'displayType' => 'Line',
	'showValues' => 0
));

$genreChart->addTrendLine("TRK", 350);




$songList = new TableComponent();
$songList->setCaption("Tabela","Tabela: {{label}}");
$songList->setDataSource($dataSource);
$songList->setDimensions(4,1);
$songList->addColumn("Data", "dat_ref", array('displayAsRange' => 'time', 'timeUnit' => 'month','groupBy' => true));
$songList->addColumn("GEO", "nom_abr_unb_dir", array('groupBy' => true));
$songList->addColumn("CDD", "nom_abr_unb", array('groupBy' => true));
$songList->addColumn("EMB", "nom_lin_emb_consolid", array('groupBy' => true));
$songList->addColumn("TT", "qtd_total_sku", array(
	'numberSuffix'=>" hl",
	'width' => 60,
	'aggregate' => true	
	
));

$kpi = new KPIComponent();
$kpi->setCaption("TT Brasil Mes x Mes","Venda Mes x Mes: {{label}}");
$kpi->setDimensions(2,1);
$kpi->setDataSource($dataSource);
$kpi->setValueExpression("qtd_total_sku", array(
	'aggregate' => true,
	'aggregateFunction' => 'SUM',
	'groupBy'=>'dat_ref',
	'numberSuffix' => ' (HL)',
	
	));


$totalCerveja = new KPIComponent();
$totalCerveja->setCaption("TT Cerveja Brasil Mes");
$totalCerveja->setDimensions(1,1);
$totalCerveja->setDataSource($dataSource);
$totalCerveja->setValueFromSQLQuery("SELECT sum(qtd_total_sku) as TT_CERVEJA FROM 
	kpi_volume_ttv where nom_tipo_marca_prod = 'cerveja' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_CERVEJA',
		'numberSuffix' => ' (HL)'
		
));


$totalRefri = new KPIComponent();
$totalRefri->setCaption("TT Refri Brasil Mes");
$totalRefri->setDimensions(1,1);
$totalRefri->setDataSource($dataSource);
$totalRefri->setValueFromSQLQuery("SELECT sum(qtd_total_sku) as TT_REFRI FROM 
	kpi_volume_ttv where nom_tipo_marca_prod = 'refrigerante' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_REFRI',
		'numberSuffix' => ' (HL)'
		
));



//Criando autolink entre o grafico de vendas da regional com vendas do cdd
$vendasRegional->autoLink($vendasProduto);
$vendasRegional->autoLink($genreChart);
$vendasRegional->autoLink($songList);
$vendasProduto->autoLink($genreChart);
$vendasRegional->autoLink($kpi);
$vendasRegional->autoLink($totalCerveja);
$vendasRegional->autoLink($totalRefri);

//Filtros
$filter->addFilterTo($vendasRegional);
$filter->addFilterTo($vendasProduto);
$filter->addFilterTo($genreChart);

Dashboard::addComponent($filter);
Dashboard::addComponent($vendasRegional);
Dashboard::addComponent($vendasProduto);
Dashboard::addComponent($genreChart);
Dashboard::addComponent($songList);
Dashboard::addComponent($kpi);
Dashboard::addComponent($totalCerveja);
Dashboard::addComponent($totalRefri);

//Renderizando o Dashboard
Dashboard::Render();

?>
-->