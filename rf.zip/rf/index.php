<html>
  <head>
    <title>RazorFlow Embedded Dashboard</title>
   <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="razorflow.jquery.js" type="text/javascript"></script>

    <script type='text/javascript'>
      $(document).ready(function(){
        $("#dashboardTarget").razorflow({
          url: 'mydash2.php'
        });
      });
    </script>
  </head>
  <body>
    <h2>Sales Dashboard</h2>
    <div id="dashboardTarget"></div>
  </body>
</html>