<html>
<head>
<title>Extraindo dados de um  Banco de Dados</title>
</head>
<body>

<?php
$fp = fopen("bloco1.txt", "w");

fwrite($fp, '<?php'.PHP_EOL);
fwrite($fp, 'require("razorflow.php");'.PHP_EOL);
fwrite($fp, 'Dashboard::setTitle("Dashboard de Vendas");'.PHP_EOL);

mysql_connect("localhost", "root", "") or die (mysql_error ());
mysql_select_db("dashboard") or die(mysql_error());


//Criando o primeiro grafico ($chart)
fwrite($fp, '$chart = new ChartComponent;'.PHP_EOL);
fwrite($fp, '$chart->setCaption("Tracking BRASIL Acumulado");.PHP_EOL');
fwrite($fp, '$chart->setDimensions(4,2);'.PHP_EOL);




$chart->setStaticLabels("Regional", array("SPC", "NE", "CO", "NO", "RJ", "RSSC", "PRSPI", "MGES",));
$chart->addStaticSeries("Real (hl)", array(30, 23, 22, 23,30, 22,33,28,), array(
	'numberSuffix' => " (hl)"
	
));
$chart->addStaticSeries("Tracking", array(13, 12, 11, 13, 22 ,11,23,33,), array(
	'numberSuffix' => " (hl)",
	'displayType' => "Line"
));





$strSQL = "SELECT nom_abr_unb_dir, val_real FROM kpi_volume_ttv_tracking WHERE dia ='2014-08-01'";

// Executa a query (o recordset $rs contém o resultado da query)
$rs = mysql_query($strSQL);
$geo = "";	
$geoValues = "";

while($row = mysql_fetch_array($rs)) 
{
	$geo = $geo . '"' . $row['nom_abr_unb_dir'] . '",';
	$geoValues = $geoValues . intval($row['val_real']) . ',';
	 // $escreve = fwrite($fp, $row['nom_abr_unb_dir']."," );

//echo $row['nom_abr_unb_dir'] . ",";

}
fwrite($fp, '?>');
fclose($fp); 
mysql_close();
echo $geo;
echo "<br>";
echo $geoValues;
?>
</body>
</html>

