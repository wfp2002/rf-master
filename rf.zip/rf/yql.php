

<?php  

    //Criando a url para o aquivo json
    $jsonurl = "[url=']";

    //Retorna o conteudo do arquivo em formato de string
    $json = file_get_contents("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.xchange%20where%20pair%20in%20(%22EURBRL%22%2C%22USDBRL%22)&format=json&diagnostics=true&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys&callback="); 
    

    //Decodificando a string e criando o json
    $json_output = json_decode($json); 




    //var_dump(  $json_output);
	//echo "<br><br><br>";
	 $t =  $json_output->query->results->rate;
	//var_dump($t);
	
	
	
	foreach ( $t as $e )
	    {
		echo "nome: $e->id - Valor: $e->Ask<br/>"; 
	}


	
?>


