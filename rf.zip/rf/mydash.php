<?php
//Incluindo a biblioteca
require('razorflow.php');

//Nome do Dashboard
Dashboard::setTitle ("DASH Modelo");

//Criando o DataSource
$dataSource = new MySQLDataSource('blog', 'root', '', 'localhost');
$dataSource->setSQLSource("user JOIN nomes ON user.password = nomes.password
							    JOIN vendas ON user.password = vendas.password
						  ");
						  
					
//$dataSource->setSQLSource('user NATURAL JOIN nomes');
//ou
//$dataSource->setSQLSource("user u, nomes n WHERE u.password = n.password");
//Nao e necessario escrever select * from 


$filter = new ConditionFilterComponent();
$filter->setDimensions(1, 1);
$filter->setDataSource($dataSource);
$filter->setCaption("Select a name");
$filter->addSelectCondition("Year", array("fa", "carol", "eliane"), array(
    "nomes.nome = 'fa'",
    "nomes.nome = 'carol'",
    "nomes.nome = 'eliane'"
));


// Criando grafico de Vendas Regional
$genreSales = new ChartComponent();
$genreSales->setCaption ("Vendas Regional");
$genreSales->setDimensions(1, 1);
$genreSales->setDataSource($dataSource);
$genreSales->setLabelExpression("Genre", "user.username");
$genreSales->addSeries("Sales", "user.password * 2", array('sort' => "DESC", 'color' => "223965"));






// Criando o Grafico Vendas CDD
$artistSales = new ChartComponent();
$artistSales->setCaption("Vendas CDDs");
$artistSales->setDimensions(1, 1);
$artistSales->setDataSource($dataSource);
$artistSales->setLabelExpression("Nome", "nomes.nome");
$artistSales->addSeries("TRK", "nomes.password * 2", array('sort' => "DESC", 'color' => "223965", 'displayType' => "Column", 'numberPrefix' => "$"));
$artistSales->setOption('limit', 10);


// Criando o grafico de KPI apenas com TT e um mini bar-graph
$kpi = new KPIComponent();
$kpi->setCaption('TT Brasil');
$kpi->setDimensions(1, 1);
$kpi->setStaticCurrentValue(42);
$kpi->setStaticPastValues(array(12, 2, 55, 23, 12));


// Create and configure a chart component
$gauge = new GaugeComponent();
$gauge->setCaption("Gauge AVG");
$gauge->setDataSource($dataSource);
$gauge->setDimensions(1, 1);
$gauge->setValueExpression("nomes.password * 2", array('aggregate' => "true",'aggregateFunction' => "AVG",'numberSuffix' => " days"));


	
// Create and configure a chart component
$chart = new ChartComponent();
$chart->setCaption("Chart");
$chart->setDataSource($dataSource);
$chart->setDimensions(2, 1);
$chart->setYAxis("Revenue", array('numberPrefix' => '$'));
$chart->setLabelExpression("Nome", "nomes.nome");
$chart->addSeries("TRK", "nomes.password * 2", array('displayType' => "Line", 'numberPrefix' => "$"));
$chart->addSeries("Real", "nomes.password * 3", array('displayType' => "Line", 'numberPrefix' => "$"));


//$chart->addStaticSeries("Series 1", array(10, 20,20), array('color' => "A4C9F3", 'displayType' => "Line"));
//$chart->addStaticSeries("Series 2", array(15, 10,12), array('color' => "bc34df", 'displayType' => "Line"));


$pie = new ChartComponent();
$pie->setDimensions(1, 1);
$pie->setCaption("Pizza");
$pie->setDataSource($dataSource);
$pie->setYAxis("Revenue", array('numberPrefix' => '$'));
$pie->setLabelExpression("Nome", "nomes.nome");
$pie->addSeries("TRK", "nomes.password * 2", array('sort' => "DESC", 'color' => "223965", 'displayType' => "Pie", 'numberPrefix' => "$"));
	
	
$revenueChart = new ChartComponent();
$revenueChart->setCaption("Revenue By Year");
$revenueChart->setDimensions(2, 1);
$revenueChart->setDataSource($dataSource);
$revenueChart->setYAxis("Revenue", array('numberPrefix' => '$'));
$revenueChart->setLabelExpression("Nome", "nomes.nome");
$revenueChart->addSeries("TRK", "nomes.password * 2", array('displayType' => "Area", 'numberPrefix' => "$"));


$drillCategory = new ChartComponent();
$drillCategory->setDimensions(2, 1);
$drillCategory->setCaption("Drill-down por Funcionario", "Vendas de: {{value}}");
$drillCategory->setYAxis("Sales", array('numberPrefix' => "$"));
$drillCategory->setDataSource($dataSource);
$drillCategory->setLabelExpression("Nomes", "nomes.nome", array('drillPath' => array('nomes.nome','vendas.dat_ref', 'vendas.produto')));
$drillCategory->addSeries("Vendas", "vendas.valor", array(
	'displayType' => 'Column'
));



$drillTime = new ChartComponent();
$drillTime->setCaption("Drill-down Ano", "Vendas: {{value}}");
$drillTime->setYAxis("Vendas (hl)", array('numberPrefix' => "(hl) "));
$drillTime->setDimensions(4, 2);
$drillTime->setDataSource($dataSource);
$drillTime->setLabelExpression("Ano", "vendas.dat_ref", array(
	'timestampRange' => true,
	'autoDrill' => true
));
$drillTime->addSeries("Vendas", "vendas.valor", array(
	'color' => "ff6e00",
	'displayType' => 'Column'
));


$salesTable = new TableComponent();
$salesTable->setCaption("teste");
$salesTable->setDimensions(2, 1);
$salesTable->setDataSource($dataSource);
$salesTable->addColumn("user", "user.username");
$salesTable->addColumn("pass", "user.password", array('textColor' => 'red'));
$salesTable->addColumn("nome", "nomes.nome");
$salesTable->addColumn("passwd", "nomes.password");
$salesTable->addColumn("passwd", "nomes.password");
$salesTable->addColumn("xxxx", "nomes.password * user.password");
$salesTable->addColumn("yyyy*2", "nomes.password * 2");
$salesTable->addColumn("yyyy*3", "nomes.password * 3");
$salesTable->addColumn("yyyy*4", "nomes.password * 4");
$salesTable->addColumn("yyyy*5", "nomes.password * 5", array('numberPrefix' => ' $',  'width' => 60, 'decimals' => 2));




$chart0 = new ChartComponent;
$chart0->setCaption("Quarterly Performance");
$chart0->setYAxis("Sales");
$chart0->setDimensions(2,1);
$chart0->setSecondYAxis("Sales Growth", array(
	'numberSuffix' => "%"
));
$chart0->setStaticLabels("Quarter", array("Q1", "Q2", "Q3", "Q4"));
$chart0->addStaticSeries("Store A", array(55, 23, 44, 23), array(
	'numberPrefix' => "$ ",
	'decimals'=>2
));
$chart0->addStaticSeries("Store B", array(12, 41, 37, 47), array(
	'numberPrefix' => "$ ", 
	'decimals' => 2
));
$chart0->addStaticSeries("Increase", array(13, 12, 11, 13), array(
	'displayType' => "Line",
	'onSecondYAxis' => true
));
	
//Criando autolink entre o grafico de vendas da regional com vendas do cdd
$genreSales->autoLink($artistSales);
$genreSales->autoLink($gauge);


//Adicionando os graficos criados

Dashboard::addComponent($filter);
Dashboard::addComponent($genreSales);
Dashboard::addComponent($artistSales);
Dashboard::addComponent($kpi);
Dashboard::addComponent($gauge);	
Dashboard::addComponent($chart);	
Dashboard::addComponent($pie);	
Dashboard::addComponent($revenueChart);
Dashboard::addComponent($drillCategory);
Dashboard::addComponent($drillTime);
Dashboard::addComponent($salesTable);
Dashboard::addComponent($chart0);

//Filtros
$filter->addFilterTo($genreSales);



//Renderizando o Dashboard
Dashboard::Render();

?>
