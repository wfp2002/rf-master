<?php
//Incluindo a biblioteca
require('razorflow.php');


$twitterDS = new JSONDataSource();
$twitterDS->setUrl('http://192.168.0.124/rf/exemplo_json.php');
$twitterDS->setSchema ( array (
        'nom_abr_unb_dir' => array('type' => 'text')));


$table = new TableComponent();
$table->setDataSource($twitterDS);

$table->addColumn("GEO", "nom_abr_unb_dir");

Dashboard::addComponent($table);
/*
//Nome do Dashboard
Dashboard::setTitle ("DASH Vendas");

//Criando o DataSource
$dataSource = new MySQLDataSource('fui', 'root', '', 'localhost');
$dataSource->setSQLSource("KPI_VOLUME_TTV");
						  

$filter = new ConditionFilterComponent();
$filter->setDimensions(1, 1);
$filter->setDataSource($dataSource);
$filter->setCaption("Regional");
$filter->addSelectCondition("Regional", array("GEO SPC", "GEO RJ"), array(
  "KPI_VOLUME_TTV.nom_abr_unb_dir = 'GEO SPC'",
  "KPI_VOLUME_TTV.nom_abr_unb_dir = 'GEO RJ'"
  
));



// Criando grafico de Vendas Regional
$vendasRegional = new ChartComponent();
$vendasRegional->setCaption ("Vendas Regional");
$vendasRegional->setDimensions(3, 1);
$vendasRegional->setDataSource($dataSource);
$vendasRegional->setLabelExpression("Regional", "KPI_VOLUME_TTV.nom_abr_unb_dir", array('autoDrill' => true));
$vendasRegional->addSeries("Vendas", "KPI_VOLUME_TTV.qtd_total_sku", array('sort' => "DESC", 'color' => "223965"));

// Criando grafico de Vendas Regional
$vendasProduto = new ChartComponent();
$vendasProduto->setCaption("Mais Vendidos","Mais Vendidos: {{label}}");
$vendasProduto->setDimensions(4, 1);
$vendasProduto->setDataSource($dataSource);
$vendasProduto->setLabelExpression("Produto", "KPI_VOLUME_TTV.nom_prod", array('autoDrill' => true));
$vendasProduto->addSeries("Vendas", "KPI_VOLUME_TTV.qtd_total_sku", array('sort' => "DESC", 'color' => "223965"
));

$genreChart = new ChartComponent();
$genreChart->setDimensions(4,2);
$genreChart->setCaption("Grafico Produtos","Grafico Produtos: {{label}}");
$genreChart->setDataSource($dataSource);
$genreChart->setLabelExpression("Month", "kpi_volume_ttv.dat_ref", array(
	'timestampRange' => true,
	'timeUnit' => 'month',
	'autoDrill' => true
));

$genreChart->addSeries("CERVEJA", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'CERVEJA'",
	'displayType' => 'Line',
	'showValues' => 0
));


$genreChart->addSeries("REFRI", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'REFRIGERANTE'",
	'displayType' => 'Line',
	'showValues' => 0
));

$genreChart->addSeries("REFRI LATA 350", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'REFRIGERANTE' AND kpi_volume_ttv.nom_lin_emb_consolid = 'LATA 350'",
	
	'displayType' => 'Line',
	'showValues' => 0
));

$genreChart->addTrendLine("TRK", 350);




$songList = new TableComponent();
$songList->setCaption("Tabela","Tabela: {{label}}");
$songList->setDataSource($dataSource);
$songList->setDimensions(4,1);
$songList->addColumn("Data", "dat_ref", array('displayAsRange' => 'time', 'timeUnit' => 'month','groupBy' => true));
$songList->addColumn("GEO", "nom_abr_unb_dir", array('groupBy' => true));
$songList->addColumn("CDD", "nom_abr_unb", array('groupBy' => true));
$songList->addColumn("EMB", "nom_lin_emb_consolid", array('groupBy' => true));
$songList->addColumn("TT", "qtd_total_sku", array(
	'numberSuffix'=>" hl",
	'width' => 60,
	'aggregate' => true	
	
));

$kpi = new KPIComponent();
$kpi->setCaption("TT Brasil Mes x Mes","Venda Mes x Mes: {{label}}");
$kpi->setDimensions(2,1);
$kpi->setDataSource($dataSource);
$kpi->setValueExpression("qtd_total_sku", array(
	'aggregate' => true,
	'aggregateFunction' => 'SUM',
	'groupBy'=>'dat_ref',
	'numberSuffix' => ' (HL)',
	
	));


$totalCerveja = new KPIComponent();
$totalCerveja->setCaption("TT Cerveja Brasil Mes");
$totalCerveja->setDimensions(1,1);
$totalCerveja->setDataSource($dataSource);
$totalCerveja->setValueFromSQLQuery("SELECT sum(qtd_total_sku) as TT_CERVEJA FROM 
	kpi_volume_ttv where nom_tipo_marca_prod = 'cerveja' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_CERVEJA',
		'numberSuffix' => ' (HL)'
		
));


$totalRefri = new KPIComponent();
$totalRefri->setCaption("TT Refri Brasil Mes");
$totalRefri->setDimensions(1,1);
$totalRefri->setDataSource($dataSource);
$totalRefri->setValueFromSQLQuery("SELECT sum(qtd_total_sku) as TT_REFRI FROM 
	kpi_volume_ttv where nom_tipo_marca_prod = 'refrigerante' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_REFRI',
		'numberSuffix' => ' (HL)',
	
		
));


//Criando autolink entre o grafico de vendas da regional com vendas do cdd
$vendasRegional->autoLink($vendasProduto);
$vendasRegional->autoLink($genreChart);
$vendasRegional->autoLink($songList);
$vendasProduto->autoLink($genreChart);
$vendasRegional->autoLink($kpi);
$vendasRegional->autoLink($totalCerveja);
$vendasRegional->autoLink($totalRefri);

//Filtros
$filter->addFilterTo($vendasRegional);
$filter->addFilterTo($vendasProduto);
$filter->addFilterTo($genreChart);

Dashboard::addComponent($filter);
Dashboard::addComponent($vendasRegional);
Dashboard::addComponent($vendasProduto);
Dashboard::addComponent($genreChart);
Dashboard::addComponent($songList);
Dashboard::addComponent($kpi);
Dashboard::addComponent($totalCerveja);
Dashboard::addComponent($totalRefri);


//Renderizando o Dashboard
Dashboard::Render();
*/
?>
