<?php 


$mysqli = new mysqli("127.0.0.1", "root", "", "fui");
$res = $mysqli->query("SELECT nom_abr_unb_dir, sum(qtd_total_sku) as vol_hl FROM kpi_volume_ttv
group by nom_abr_unb_dir limit 1");

// fetch all rows from the query
$all_rows = array();
while($row = $res->fetch_assoc()) {
    $all_rows []= $row;
}

header("Content-Type: application/json");
echo json_encode($all_rows);



/*
$conecta = mysql_connect("127.0.0.1", "root", "") or print (mysql_error()); 
mysql_select_db("FUI", $conecta) or print(mysql_error()); 
$sql = "SELECT nom_abr_unb_dir, sum(qtd_total_sku) as vol_hl FROM kpi_volume_ttv
group by nom_abr_unb_dir"; 
$result = mysql_query($sql, $conecta); 
 
 
while($consulta = mysql_fetch_array($result)) 
{ 
   //print $consulta[0]." - ".$consulta[1]."<br>";
    $geo[] = $consulta['nom_abr_unb_dir']; 
	$tt[] = $consulta['vol_hl'];
} 
mysql_free_result($result); 
mysql_close($conecta); 

*/




?>