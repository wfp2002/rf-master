<?php
include "razorflow.php";

Dashboard::setTitle("Dashboard de Vendas");

//Criando o DataSource
//$dataSource = new MySQLDataSource('dashboard', 'root', '', 'localhost');
//$dataSource->setSQLSource("KPI_VOLUME_TTV");

$dataSource = new MySQLDataSource('dashboard', 'root', '', 'localhost');
$dataSource->setSQLSource("KPI_VOLUME_TTV");




#function to get Mes Atual
function getMesAtual() {
	
	$dbhandle = new PDO('mysql:host=localhost;dbname=dashboard', "root", "");
	//$dbhandle = new MySQLDataSource('dashboard', 'root', '', 'localhost');
    
    $result = $dbhandle->query("select max(month(dat_ref)) as dataultima from kpi_volume_ttv where dat_ref = '2014-08-01'");
    foreach ($result as $row) {
        $mes = $row['dataultima'];
    }    

     

    $ytd = $mes;
    return $ytd; 
}





#function to get Mes Atual
function getMarcasCerveja() {
	
	$dbhandle = new PDO('mysql:host=localhost;dbname=dashboard', "root", "");
	//$dbhandle = new MySQLDataSource('dashboard', 'root', '', 'localhost');
    $marcas = array();
    $result = $dbhandle->query("select dsc_prod, sum(val_real) as val_real from kpi_volume_ttv where dat_ref = '2014-08-01' and dsc_prod in ('BUD','pepsico') and dsc_kpi = 'volume fornecimento' group by dsc_prod");
   // foreach ($result as $row) {
		
		
	 //   $data[] = $row['dsc_prod'];
	    
      //  $marcas = $row['dsc_prod'];
	//	$marcasValor = $row['val_real'];
    //}    

     

    //$ytd = $marcas;
    //return $ytd; 
	return $result;
}





$chart = new ChartComponent;
$chart->setCaption("Tracking BRASIL Acumulado","Tracking BRASIL: {{label}}");
$chart->setDimensions(4,2);
$chart->setDataSource($dataSource);
//$chart->setYAxis("Volume HL");
$chart->setLabelExpression("Regional", "KPI_VOLUME_TTV.nom_abr_unb_dir", array('autoDrill' => true));
$chart->addSeries("Vendas", "KPI_VOLUME_TTV.val_real", array('sort' => "DESC", 'color' => "223965",
'condition' => "kpi_volume_ttv.dsc_prod = 'TOTAL PRODUTO' and DAT_REF='2014-08-01' AND DSC_KPI='VOLUME FORNECIMENTO'",

));

	
$chart->addSeries("Tracking", "KPI_VOLUME_TTV.val_trk", array('sort' => "DESC", 'color' => "ff6a00",
'condition' => "kpi_volume_ttv.dsc_prod = 'TOTAL PRODUTO' and DAT_REF='2014-08-01' AND DSC_KPI='VOLUME FORNECIMENTO'", 
'displayType' => "Line",
'showValues' => 0

));



$chart2 = new ChartComponent;
$chart2->setCaption("Tracking Diario Brasil","Regional: {{label}}");
$chart2->setDimensions(4,2);
$chart2->setDataSource($dataSource);
$chart2->addCondition("month(kpi_volume_ttv.dat_ref)", "=", getMesAtual());
//$chart->setYAxis("Volume HL");
$chart2->setLabelExpression("DIAS", "KPI_VOLUME_TTV.DAT_REF", array(
	'autoDrill' => true,
	'timestampRange' => true,
	'timeUnit' => 'day'
));
$chart2->addSeries("Vendas", "KPI_VOLUME_TTV.val_real", array('color' => "223965",
'displayType' => "Line", 'showValues' => 0,
'condition' => "kpi_volume_ttv.dsc_prod = 'TOTAL PRODUTO' and kpi_volume_ttv.DSC_KPI='VOLUME TRACKING'"
));
$chart2->addSeries("Tracking", "KPI_VOLUME_TTV.val_trk", array('color' => "2e9a1c",
'displayType' => "Line", 'showValues' => 0,
'condition' => "kpi_volume_ttv.dsc_prod = 'TOTAL PRODUTO' and kpi_volume_ttv.DSC_KPI='VOLUME TRACKING'"
));
$chart2->addSeries("AVG BGT", "KPI_VOLUME_TTV.val_meta", array('color' => "e00f43",
'displayType' => "Line", 'showValues' => 0,
'condition' => "kpi_volume_ttv.dsc_prod = 'TOTAL PRODUTO' and kpi_volume_ttv.DSC_KPI='VOLUME TRACKING'"
));




$chart3 = new ChartComponent;
$chart3->setCaption("Marcas Cerveja Brasil","Marcas Cerveja: {{label}}");
$chart3->setDimensions(2,1);
$chart3->setDataSource($dataSource);
$chart3->addCondition("kpi_volume_ttv.dsc_kpi", "=", "volume marcas cerveja");

$chart3->setLabelExpression("", "KPI_VOLUME_TTV.DSC_PROD", array(
	'autoDrill' => true

));
$chart3->addSeries("MARCAS", "KPI_VOLUME_TTV.val_real", array('color' => "2c8af2",
'showValues' => 0,
'sort' => "DESC",
'condition' => "year(kpi_volume_ttv.dat_ref) = year(now()) and month(kpi_volume_ttv.dat_ref) = month(now())"
));

$marcas = new ChartComponent;
$marcas->setCaption("Marcas Refri Brasil","Marcas Refri: {{label}}");

$marcas->setDimensions(2,1);
$marcas->setDataSource($dataSource);
$marcas->addCondition("kpi_volume_ttv.dsc_kpi", "=", "volume marcas refri");

$marcas->setLabelExpression("", "KPI_VOLUME_TTV.DSC_PROD", array(
	'autoDrill' => true

));
$marcas->addSeries("MARCAS", "KPI_VOLUME_TTV.val_real", array('color' => "2e9a1c",
'showValues' => 0,
'sort' => "DESC",
'condition' => "year(kpi_volume_ttv.dat_ref) = year(now()) and month(kpi_volume_ttv.dat_ref) = month(now())"
));

$chart4 = new ChartComponent;
$chart4->setCaption("Embalagens Brasil","Embalagens: {{label}}");

$chart4->setDimensions(2,1);
$chart4->setDataSource($dataSource);
$chart4->addCondition("kpi_volume_ttv.dsc_kpi", "=", "volume embalagens");

$chart4->setYAxis("Volume HL");


$chart4->setLabelExpression("", "KPI_VOLUME_TTV.DSC_CONSOLID", array(
	'autoDrill' => true

));
$chart4->addSeries("Real", "KPI_VOLUME_TTV.val_real", array('color' => "223965",
'showValues' => 0,
'sort' => "DESC",
'condition' => "year(kpi_volume_ttv.dat_ref) = year(now()) and month(kpi_volume_ttv.dat_ref) = month(now())"
));

$chart4->addSeries("Tracking", "KPI_VOLUME_TTV.val_trk", array('color' => "ff6a00",
'showValues' => 0,
'sort' => "DESC",
'displayType' => "Line",
'condition' => "year(kpi_volume_ttv.dat_ref) = year(now()) and month(kpi_volume_ttv.dat_ref) = month(now())"
));


$chart5 = new ChartComponent;
$chart5->setCaption("Embalagens Consolid Brasil","Embalagens Consolid: {{label}}");
$chart5->setDimensions(2,1);
$chart5->setDataSource($dataSource);
$chart5->addCondition("kpi_volume_ttv.dsc_kpi", "=", "volume embalagens");
$chart5->setYAxis("Volume HL");
$chart5->setLabelExpression("", "KPI_VOLUME_TTV.dsc_prod", array(
	'autoDrill' => true

));
$chart5->addSeries("Real", "KPI_VOLUME_TTV.val_real", array('color' => "223965",
'showValues' => 0,
'sort' => "DESC",
'condition' => "year(kpi_volume_ttv.dat_ref) = year(now()) and month(kpi_volume_ttv.dat_ref) = month(now())"
));

$chart5->addSeries("Tracking", "KPI_VOLUME_TTV.val_trk", array('color' => "ff6a00",
'showValues' => 0,
'sort' => "DESC",
'displayType' => "Line",
'condition' => "year(kpi_volume_ttv.dat_ref) = year(now()) and month(kpi_volume_ttv.dat_ref) = month(now())"
));




$table = new TableComponent();
$table->setCaption("Vendas");
$table->setDimensions(4,1);
$table->addStaticColumn("Regional");
$table->addStaticColumn("Cerv.TT");
$table->addStaticColumn("OW");
$table->addStaticColumn("RGB");
$table->addStaticColumn("Litro");
$table->addStaticColumn("1/2");
$table->addStaticColumn("1/1");
$table->addStaticColumn("Lata530");
$table->addStaticColumn("BUD");
$table->addStaticColumn("Refrinanc");
$table->addStaticRow (array("CO",  29,87,36,76,23,56,34,67,89, "2/3/2002"));
$table->addStaticRow (array("SPC", 40,81,34,56,23,56,78,45,23, "2/3/2003"));
$table->addStaticRow (array("NE",  30,92,34,56,67,34,12,40,78, "2/3/2002"));
$table->addStaticRow (array("MGES", 2,87,34,56,67,34,67,78,45, "2/3/2002"));
$table->addStaticRow (array("RSSC", 4,81,12,34,45,56,76,89,45, "2/3/2003"));
$table->addStaticRow (array("PRSPI", 3,92,23,45,67,78,89,45,34, "2/3/2002"));
$table->addStaticRow (array("RJ",   4,81,23,45,23,45,23,45,67, "2/3/2003"));
$table->addStaticRow (array("NO",    3,92,34,45,56,67,78,56,45, "2/3/2002"));




$pie = new ChartComponent;
$pie->setCaption("Peso Canal - REGIONAL SPC");
$pie->setDimensions(2,2);
//$chart->setYAxis("Volume HL");
$pie->setStaticLabels("Regional", array("AS", "3PD", "ROTA"));
$pie->addStaticSeries("Real (hl)", array(30,30,40), array(
	'numberSuffix' => " (%)",
	'displayType' => "Pie"
	
	
));



$kpi = new KPIComponent();
$kpi->setCaption("TT Brasil Mes x Mes","Venda Mes x Mes: {{label}}");
$kpi->setDimensions(2,1);
$kpi->setDataSource($dataSource);

$kpi->addCondition("kpi_volume_ttv.dsc_prod", "=", "total produto");
$kpi->addCondition("kpi_volume_ttv.dsc_kpi", "=", "volume fornecimento");
$kpi->addCondition("kpi_volume_ttv.dat_ref", "<=", "2014-08-01	");

$kpi->setValueExpression("val_real", array(
	'aggregate' => true,
	'aggregateFunction' => 'SUM',
	'groupBy'=>'dat_ref',
	'numberSuffix' => ' (hl)',
	'decimals' => 1
));


$totalCerveja = new KPIComponent();
$totalCerveja->setCaption("TT Cerveja Brasil Mes");
$totalCerveja->setDimensions(1,1);
$totalCerveja->setDataSource($dataSource);
$totalCerveja->setValueFromSQLQuery("SELECT sum(val_real) as TT_CERVEJA FROM 
	kpi_volume_ttv where dsc_prod = 'cerveja total' and dsc_kpi='volume fornecimento' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_CERVEJA',
		'numberSuffix' => ' (hl)'
		
));


$totalRefri = new KPIComponent();
$totalRefri->setCaption("TT Refri Brasil Mes");
$totalRefri->setDimensions(1,1);
$totalRefri->setDataSource($dataSource);
$totalRefri->setValueFromSQLQuery("SELECT sum(val_real) as TT_REFRI FROM 
	kpi_volume_ttv where dsc_prod = 'refrigerante total' and dsc_kpi='volume fornecimento' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_REFRI',
		'numberSuffix' => ' (hl)'
		
));





$chart->autoLink($chart2);
$chart->autoLink($chart3);
$chart->autoLink($chart4);
$chart->autoLink($chart5);
$chart->autoLink($marcas);
$chart->autoLink($kpi);

$chart4->autoLink($chart5);



Dashboard::addComponent($kpi);
Dashboard::addComponent($totalCerveja);
Dashboard::addComponent($totalRefri);
Dashboard::addComponent($chart);
//Dashboard::addComponent($pie);
Dashboard::addComponent($table);
Dashboard::addComponent($chart2);
Dashboard::addComponent($chart3);
Dashboard::addComponent($marcas);
Dashboard::addComponent($chart4);
Dashboard::addComponent($chart5);


Dashboard::Render();
?>






<!--
//Nome do Dashboard
Dashboard::setTitle ("DASH Vendas");

//Criando o DataSource
$dataSource = new MySQLDataSource('fui', 'root', '', 'localhost');
$dataSource->setSQLSource("KPI_VOLUME_TTV");
						  

$filter = new ConditionFilterComponent();
$filter->setDimensions(1, 1);
$filter->setDataSource($dataSource);
$filter->setCaption("Regional");
$filter->addSelectCondition("Regional", array("GEO SPC", "GEO RJ"), array(
  "KPI_VOLUME_TTV.nom_abr_unb_dir = 'GEO SPC'",
  "KPI_VOLUME_TTV.nom_abr_unb_dir = 'GEO RJ'"
  
));



// Criando grafico de Vendas Regional
$vendasRegional = new ChartComponent();
$vendasRegional->setCaption ("Vendas Regional");
$vendasRegional->setDimensions(3, 1);
$vendasRegional->setDataSource($dataSource);
$vendasRegional->setLabelExpression("Regional", "KPI_VOLUME_TTV.nom_abr_unb_dir", array('autoDrill' => true));
$vendasRegional->addSeries("Vendas", "KPI_VOLUME_TTV.qtd_total_sku", array('sort' => "DESC", 'color' => "223965"));

// Criando grafico de Vendas Regional
$vendasProduto = new ChartComponent();
$vendasProduto->setCaption("Mais Vendidos","Mais Vendidos: {{label}}");
$vendasProduto->setDimensions(4, 1);
$vendasProduto->setDataSource($dataSource);
$vendasProduto->setLabelExpression("Produto", "KPI_VOLUME_TTV.nom_prod", array('autoDrill' => true));
$vendasProduto->addSeries("Vendas", "KPI_VOLUME_TTV.qtd_total_sku", array('sort' => "DESC", 'color' => "223965"
));

$genreChart = new ChartComponent();
$genreChart->setDimensions(4,2);
$genreChart->setCaption("Grafico Produtos","Grafico Produtos: {{label}}");
$genreChart->setDataSource($dataSource);
$genreChart->setLabelExpression("Month", "kpi_volume_ttv.dat_ref", array(
	'timestampRange' => true,
	'timeUnit' => 'month',
	'autoDrill' => true
));

$genreChart->addSeries("CERVEJA", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'CERVEJA'",
	'displayType' => 'Line',
	'showValues' => 0
));


$genreChart->addSeries("REFRI", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'REFRIGERANTE'",
	'displayType' => 'Line',
	'showValues' => 0
));

$genreChart->addSeries("REFRI LATA 350", 'kpi_volume_ttv.qtd_total_sku', array(
	'condition' => "kpi_volume_ttv.nom_tipo_marca_prod = 'REFRIGERANTE' AND kpi_volume_ttv.nom_lin_emb_consolid = 'LATA 350'",
	
	'displayType' => 'Line',
	'showValues' => 0
));

$genreChart->addTrendLine("TRK", 350);




$songList = new TableComponent();
$songList->setCaption("Tabela","Tabela: {{label}}");
$songList->setDataSource($dataSource);
$songList->setDimensions(4,1);
$songList->addColumn("Data", "dat_ref", array('displayAsRange' => 'time', 'timeUnit' => 'month','groupBy' => true));
$songList->addColumn("GEO", "nom_abr_unb_dir", array('groupBy' => true));
$songList->addColumn("CDD", "nom_abr_unb", array('groupBy' => true));
$songList->addColumn("EMB", "nom_lin_emb_consolid", array('groupBy' => true));
$songList->addColumn("TT", "qtd_total_sku", array(
	'numberSuffix'=>" hl",
	'width' => 60,
	'aggregate' => true	
	
));

$kpi = new KPIComponent();
$kpi->setCaption("TT Brasil Mes x Mes","Venda Mes x Mes: {{label}}");
$kpi->setDimensions(2,1);
$kpi->setDataSource($dataSource);
$kpi->setValueExpression("qtd_total_sku", array(
	'aggregate' => true,
	'aggregateFunction' => 'SUM',
	'groupBy'=>'dat_ref',
	'numberSuffix' => ' (HL)',
	
	));


$totalCerveja = new KPIComponent();
$totalCerveja->setCaption("TT Cerveja Brasil Mes");
$totalCerveja->setDimensions(1,1);
$totalCerveja->setDataSource($dataSource);
$totalCerveja->setValueFromSQLQuery("SELECT sum(qtd_total_sku) as TT_CERVEJA FROM 
	kpi_volume_ttv where nom_tipo_marca_prod = 'cerveja' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_CERVEJA',
		'numberSuffix' => ' (HL)'
		
));


$totalRefri = new KPIComponent();
$totalRefri->setCaption("TT Refri Brasil Mes");
$totalRefri->setDimensions(1,1);
$totalRefri->setDataSource($dataSource);
$totalRefri->setValueFromSQLQuery("SELECT sum(qtd_total_sku) as TT_REFRI FROM 
	kpi_volume_ttv where nom_tipo_marca_prod = 'refrigerante' and year(dat_ref) = year(now()) and month(dat_ref) = month(now())", array(
    	'valueColumn' => 'TT_REFRI',
		'numberSuffix' => ' (HL)'
		
));



//Criando autolink entre o grafico de vendas da regional com vendas do cdd
$vendasRegional->autoLink($vendasProduto);
$vendasRegional->autoLink($genreChart);
$vendasRegional->autoLink($songList);
$vendasProduto->autoLink($genreChart);
$vendasRegional->autoLink($kpi);
$vendasRegional->autoLink($totalCerveja);
$vendasRegional->autoLink($totalRefri);

//Filtros
$filter->addFilterTo($vendasRegional);
$filter->addFilterTo($vendasProduto);
$filter->addFilterTo($genreChart);

Dashboard::addComponent($filter);
Dashboard::addComponent($vendasRegional);
Dashboard::addComponent($vendasProduto);
Dashboard::addComponent($genreChart);
Dashboard::addComponent($songList);
Dashboard::addComponent($kpi);
Dashboard::addComponent($totalCerveja);
Dashboard::addComponent($totalRefri);

//Renderizando o Dashboard
Dashboard::Render();

?>
-->