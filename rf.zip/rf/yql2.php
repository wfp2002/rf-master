

<?php  

    
$json = file_get_contents("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.quotes%20where%20symbol%20%3D%20%20%22ABEV3.SA%22%3B&format=json&diagnostics=true&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys&callback=");
  
    //Decodificando a string e criando o json
    $json_output = json_decode($json); 




    //var_dump(  $json_output);
	//echo "<br><br><br>";
	 $t =  $json_output->query->results->quote;
	var_dump($t);
	
	
	
	//foreach ( $t as $e )
	 //   {
//		echo "nome: $e->symbol"; 
	//}


	
?>


