$(function () {
    $('#line').highcharts({
	 chart: {
	  type: 'spline',
               backgroundColor: '#161D2D'
                        },
						title: {
                text: 'MKT Share',
				 style: {
                color: '#FFF',
                fontWeight: 'bold'
            }
            },
        xAxis: {
            labels: {
					
					
                    rotation: -90,
                    style: {
						color: '#fff',
                        fontSize: '13px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                },
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
		
		yAxis: {
		labels: {
					
					
                    style: {
						color: '#fff',
                        fontSize: '10px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                },
			    min: 0,
                title: {
                    text: null
                }
            },
        
        plotOptions: {
            series: {
				showInLegend: false 
                
            }
        },
        
        series: [
			{
			name: 'Cerv.TT',
            data: [29.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4],
			color: '#F87C0A'
			},
			{
			name: 'RefriNanc',
            data: [190.9, 261.5, 10.4, 29.2, 44.0, 76.0, 15.6, 84.5, 170.4, 94.1, 195.6, 154.4],
			color: '#00A9FF'
			}
			]
    });
});