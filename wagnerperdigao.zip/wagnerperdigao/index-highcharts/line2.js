$(function () {
    $('#line2').highcharts({
	 chart: {
				type: 'spline',
               backgroundColor: 'transparent'
                        },
						title: {
                text: 'Vol. Cerv.TT',
				 style: {
                color: '#000',
                fontWeight: 'bold'
            }
            },
        xAxis: {
            labels: {
					
					
                    rotation: -90,
                    style: {
						color: '#000',
                        fontSize: '13px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                },
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
		
		yAxis: {
		labels: {
					
					
                    style: {
						color: '#000',
                        fontSize: '10px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                },
			    min: 0,
                title: {
                    text: null
                }
            },
        
        plotOptions: {
            series: {
				showInLegend: false,   
                dataLabels: {
                    align: 'left',
					
					color: '#000',
                    enabled: true,
                    rotation: 270,
                    x: 2,
                    y: -10
                }
            }
        },
        
        series: [{
            data: [29.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]        
        }]
    });
});